import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { routes } from "./routes/routes";
import "./App.css";
import Contact from "./components/Contactus/Contact";

const router = createBrowserRouter(routes);
function App() {
  return (
    <>
      <RouterProvider router={router} />
      <Contact />
    </>
  );
}

export default App;

// Event-Mangement-ReactJS
